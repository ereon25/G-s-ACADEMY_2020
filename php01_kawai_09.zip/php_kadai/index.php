<!DOCTYPE html>
<html lang="ja">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>php課題</title>
    <link rel="stylesheet" href="css/reset.css" />
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>

  
    <?php
    // --------------------
    // タイトル表示
    // --------------------
    $title = '<p class="title"><img src="img/title.png" alt=""></p>';
    echo $title;
    // --------------------
    // 矢印
    // --------------------
    // 矢印画像の表示
    // 一つずつ
    $box_no = '<p><img class="box" src="img/box_no.png" alt=""></p>';
    $box_no_center = '<p class="center_face"><img class="center" src="img/face.png" alt=""></p>';
    $box_u = '<p id="u"><img class="box" src="img/box_u.png" alt="上"></p>';
    $box_m = '<p id="m"><img class="box" src="img/box_m.png" alt="右"></p>';
    $box_s = '<p id="s"><img class="box" src="img/box_s.png" alt="下"></p>';
    $box_h = '<p id="h"><img class="box" src="img/box_h.png" alt="左"></p>';
    // 三つで一つ
    $y1 = "<div class='y1'>".$box_no. $box_u. $box_no."<br>"."</div>";
    $y2 = "<div class='y2'>".$box_h.$box_no_center.$box_m."<br>"."</div>";
    $y3 = "<div class='y3'>".$box_no. $box_s. $box_no."<br>"."</div>";
    // すべてまとめて
    $y = "<div class='y'>".$y1. $y2. $y3."<br>"."</div>";
    echo $y;
    // --------------------
    // ボタン準備
    // --------------------
    $btn_s = '<p id="btn_s" class="btn">再挑戦</p>';
    $btn_f = '<p id="btn_f" class="btn">終了</p>';
    $btn = "<div class='btn'>".$btn_s. $btn_f."<br>"."</div>";
    echo $btn;
    // --------------------
    // 結果表示
    // --------------------
    $result = "<div class='result'>"."<p>"."</p>"."</div>"."<br>";
    echo $result;
    
    ?>


    <!-- jquery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- js -->
    <script src='js/app.js'></script>
  </body>
</html>
