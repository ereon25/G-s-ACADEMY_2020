$(function () {
  // この中に書く
  /*-------------------------
     ボタンクリック後の操作
  ---------------------------*/
  // 終了------------------
  $("#btn_f").on("click", function () {
    $(".center_face").html(
      '<p class="face"><img src="img/finish.png" alt="上の顔" height=240px width=280px></p>'
    );
    // 矢印を消す
    $("#u").html(
      '<p id="u"><img src="img/box_no.png" alt="上" height=130px></p>'
    );
    $("#m").html(
      '<p id="m"><img src="img/box_no.png" alt="右" height=130px></p>'
    );
    $("#s").html(
      '<p id="s"><img src="img/box_no.png" alt="下" height=130px></p>'
    );
    $("#h").html(
      '<p id="h"><img src="img/box_no.png" alt="左" height=130px></p>'
    );
    // 結果を戻す
    $(".result p").html("<p></p>");
    // ↓クリックの閉じかっこ
  });
  // スタート------------------
  $("#btn_s").on("click", function () {
    $(".center").html('<img class="face" src="img/face.png" alt="正面の顔">');
    $(".center_face").html(
      '<p class="face"><img src="img/face.png" alt="正面の顔" height=240px width=280px></p>'
    );
    // 矢印を元に戻す
    $("#u").html(
      '<p id="u"><img src="img/box_u.png" alt="上" height=130px></p>'
    );
    $("#m").html(
      '<p id="m"><img src="img/box_m.png" alt="右" height=130px></p>'
    );
    $("#s").html(
      '<p id="s"><img src="img/box_s.png" alt="下" height=130px></p>'
    );
    $("#h").html(
      '<p id="h"><img src="img/box_h.png" alt="左" height=130px></p>'
    );
    // 結果を戻す
    $(".result p").html("<p></p>");
    // リロード設定
    window.location.reload();
    // ↓クリックの閉じかっこ
  });

  /*-------------------------
     あっちむいてほい
  ---------------------------*/
  // 乱数を作る
  var random = Math.floor(Math.random() * 4 + 1);
  console.log(random);
  // クリックした時
  // 上-------------------------
  $("#u").on("click", function () {
    // 選択状態
    $("#u").html(
      '<p id="u"><img src="img/box_u1.png" alt="上選択" height=130px></p>'
    );
    // その他の状態
    // 矢印を元に戻す
    $("#m").html(
      '<p id="m"><img src="img/box_m.png" alt="右" height=130px></p>'
    );
    $("#s").html(
      '<p id="s"><img src="img/box_s.png" alt="下" height=130px></p>'
    );
    $("#h").html(
      '<p id="h"><img src="img/box_h.png" alt="左" height=130px></p>'
    );
    // 結果を戻す
    $(".result p").html("<p></p>");
    // ------------------
    // 負け数数える
    var lose = 0;
    // 1=上、2=右、3=下、4=左
    // 勝ち
    if (random == 1) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_u.png" alt="上の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/win.png" alt="あなたの勝ち" height=240px width=280px></p>'
      );
      // 負け
    } else if (random == 2) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_m.png" alt="右の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    } else if (random == 3) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_s.png" alt="下の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    } else if (random == 4) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_h.png" alt="左の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    }
    // ↓クリックの閉じかっこ
  });

  // 右-------------------------
  $("#m").on("click", function () {
    // 選択状態
    $("#m").html(
      '<p id="m"><img src="img/box_m1.png" alt="右選択" height=130px></p>'
    );
    // その他の状態
    // 矢印を元に戻す
    $("#u").html(
      '<p id="u"><img src="img/box_u.png" alt="上" height=130px></p>'
    );
    $("#s").html(
      '<p id="s"><img src="img/box_s.png" alt="下" height=130px></p>'
    );
    $("#h").html(
      '<p id="h"><img src="img/box_h.png" alt="左" height=130px></p>'
    );
    // 結果を戻す
    $(".result p").html("<p></p>");
    // ------------------
    // 負け数数える
    var lose = 0;
    // 1=上、2=右、3=下、4=左
    // 勝ち
    if (random == 2) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_m.png" alt="右の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/win.png" alt="あなたの勝ち" height=240px width=280px></p>'
      );
      // 負け
    } else if (random == 1) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_u.png" alt="上の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    } else if (random == 3) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_s.png" alt="下の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    } else if (random == 4) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_h.png" alt="左の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    }
    // ↓クリックの閉じかっこ
  });
  // 下-------------------------
  $("#s").on("click", function () {
    // 選択状態
    $("#s").html(
      '<p id="s"><img src="img/box_s1.png" alt="下選択" height=130px></p>'
    );
    // その他の状態
    // 矢印を元に戻す
    $("#u").html(
      '<p id="u"><img src="img/box_u.png" alt="上" height=130px></p>'
    );
    $("#m").html(
      '<p id="m"><img src="img/box_m.png" alt="右" height=130px></p>'
    );
    $("#h").html(
      '<p id="h"><img src="img/box_h.png" alt="左" height=130px></p>'
    );
    // 結果を戻す
    $(".result p").html("<p></p>");
    // ------------------
    // 負け数数える
    var lose = 0;
    // 1=上、2=右、3=下、4=左
    // 勝ち
    if (random == 3) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_s.png" alt="下の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/win.png" alt="あなたの勝ち" height=240px width=280px></p>'
      );
      // 負け
    } else if (random == 1) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_u.png" alt="上の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    } else if (random == 2) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_m.png" alt="右の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    } else if (random == 4) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_h.png" alt="左の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    }
    // ↓クリックの閉じかっこ
  });
  // 左-------------------------
  $("#h").on("click", function () {
    // 選択状態
    $("#h").html(
      '<p id="h"><img src="img/box_h1.png" alt="左選択" height=130px></p>'
    );
    // その他の状態
    // 矢印を元に戻す
    $("#u").html(
      '<p id="u"><img src="img/box_u.png" alt="上" height=130px></p>'
    );
    $("#m").html(
      '<p id="m"><img src="img/box_m.png" alt="右" height=130px></p>'
    );
    $("#s").html(
      '<p id="s"><img src="img/box_s.png" alt="下" height=130px></p>'
    );
    // 結果を戻す
    $(".result p").html("<p></p>");
    // ------------------
    // 負け数数える
    var lose = 0;
    // 1=上、2=右、3=下、4=左
    // 勝ち
    if (random == 4) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_h.png" alt="左の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/win.png" alt="あなたの勝ち" height=240px width=280px></p>'
      );
      // 負け
    } else if (random == 1) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_u.png" alt="上の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    } else if (random == 2) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_m.png" alt="右の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    } else if (random == 3) {
      $(".center_face").html(
        '<p class="face"><img src="img/face_s.png" alt="下の顔" height=240px width=280px></p>'
      );
      $(".result p").html(
        '<p><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
      );
      lose++;
      console.log(lose);
    }
    // ↓クリックの閉じかっこ
  });
  // この下は消さない
});

// if (lose == 1) {
//   $(".center_face").html(
//     '<p class="face"><img src="img/3.png" alt="あいこ1回目" height=240px width=280px></p>'
//   );
// } else if (lose == 2) {
//   $(".center_face").html(
//     '<p class="face"><img src="img/2.png" alt="あいこ2回目" height=240px width=280px></p>'
//   );
// } else if (lose == 3) {
//   $(".center_face").html(
//     '<p class="face"><img src="img/1.png" alt="あいこ3回目" height=240px width=280px></p>'
//   );
// } else if (lose == 4) {
//   $(".center_face").html(
//     '<p class="face"><img src="img/lose.png" alt="あなたの負け" height=240px width=280px></p>'
//   );
// }
// 上の時----------------------
// $("#u").on("click", function () {
//   if (random == 1) {
//     // 勝ったとき---
//     $(".center_face").html(
//       '<p class="face"><img src="img/win.png" alt="あなたの勝ち" height=240px width=280px></p>'
//     );
//   } else {
//     // 負けたとき---
//     lose++;
//   }
// // 勝ったとき---
// $(".center_face").html(
//   '<p class="face"><img src="img/win.png" alt="あなたの勝ち" height=240px width=280px></p>'
// );
