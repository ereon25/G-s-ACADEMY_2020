$(document).ready(function () {
  // ↓これよりも下に記述する
  /* -----------------------
          idデータを取得 
      --------------------------*/
  // 「location.search」はURLのクエリ部分だけを抽出→「?id=」の部分
  var query = location.search;
  //   「split()」を使って「=」の部分で2つに分割→「?id」「～」に分けた配列にする。
  var value = query.split("=");
  var id = decodeURIComponent(value[1]);
  console.log(id);
  /* -----------------------
          データ取得 
   --------------------------*/
  newPostRef.on("child_added", function (data) {
    var all = data.val();
    console.log(all);
    var all_key = data.key;
    console.log(all_key);

    if (all_key == id) {
      /* -----------------------
      一致したときにデータ詳細取得
      --------------------------*/
      // 現在の日時まとめ--------------------
      var t1 = `${all.患者情報.時刻情報.日付}`;
      var t2 = `${all.患者情報.時刻情報.時刻}`;
      // 個人情報まとめ--------------------
      var p1 = `${all.患者情報.個人情報.名前}`;
      var p2 = `${all.患者情報.個人情報.生年月日}`;
      var p3 = `${all.患者情報.個人情報.性別}`;
      var p4 = `${all.患者情報.個人情報.住所}`;
      var p5 = `${all.患者情報.個人情報.電話番号}`;
      // 症状まとめ--------------------
      var s1 = `${all.患者情報.症状情報.今回の症状}`;
      var s2_1 = `${all.患者情報.症状情報.病歴について.病歴}`;
      var s2_2 = `${all.患者情報.症状情報.病歴について.そのほか詳細}`;
      var s3_1 = `${all.患者情報.症状情報.服用薬について.服用薬の有無}`;
      var s3_2 = `${all.患者情報.症状情報.服用薬について.服用薬詳細}`;
      var s4_1 = `${all.患者情報.症状情報.アレルギーについて.アレルギーの有無}`;
      var s4_2 = `${all.患者情報.症状情報.アレルギーについて.アレルギー詳細}`;
      var s5_1 = `${all.患者情報.症状情報.飲酒について.飲酒の有無}`;
      var s5_2 = `${all.患者情報.症状情報.飲酒について.飲酒頻度}`;
      var s6_1 = `${all.患者情報.症状情報.喫煙について.喫煙の有無}`;
      var s6_2 = `${all.患者情報.症状情報.喫煙について.喫煙頻度}`;
      var s7_1 = `${all.患者情報.症状情報.妊娠授乳について.妊娠の有無}`;
      var s7_2 = `${all.患者情報.症状情報.妊娠授乳について.授乳の有無}`;
      var s8 = `${all.患者情報.症状情報.その他質問コメントなど}`;
      /* -----------------------
        表の作成
    --------------------------*/
      var thead = `
        <tr>
            <th class="t">項目</th>
            <th class="t">項目詳細</th>
        </tr>s
        `;
      var tbody = `
        // 現在の日時まとめ--------------------
        <tr>
        <td class="t">日付</td>
        <td >${t1}</td>
        </tr>
        <tr>
        <td class="t">時刻</td>
        <td >${t2}</td>
        </tr>
        // 個人情報まとめ--------------------
        <tr>
        <td class="t">名前</td>
        <td >${p1}</td>
        </tr>
        <tr>
        <td class="t">生年月日</td>
        <td >${p2}</td>
        </tr>
        <tr>
        <td class="t">性別</td>
        <td >${p3}</td>
        </tr>
        <tr>
        <td class="t">住所</td>
        <td >${p4}</td>
        </tr>
        <tr>
        <td class="t">電話番号</td>
        <td >${p5}</td>
        </tr>
        // 症状まとめ--------------------
        <tr>
        <td class="t">今回の症状</td>
        <td >${s1}</td>
        </tr>
        <tr>
        <td class="t">病歴</td>
        <td >${s2_1}</td>
        </tr>
        <tr>
        <td class="t">( 病歴詳細 )</td>
        <td >${s2_2}</td>
        </tr>
        <tr>
        <td class="t">服用薬の有無</td>
        <td >${s3_1}</td>
        </tr>
        <tr>
        <td class="t">( 服用薬詳細 )</td>
        <td >${s3_2}</td>
        </tr>
        <tr>
        <td class="t">アレルギーの有無</td>
        <td >${s4_1}</td>
        </tr>
        <tr>
        <td class="t">( アレルギー詳細 )</td>
        <td >${s4_2}</td>
        </tr>
        <tr>
        <td class="t">飲酒の有無</td>
        <td >${s5_1}</td>
        </tr>
        <tr>
        <td class="t">( 飲酒頻度 )</td>
        <td >${s5_2}</td>
        </tr>
        <tr>
        <td class="t">喫煙の有無</td>
        <td >${s6_1}</td>
        </tr>
        <tr>
        <td class="t">( 喫煙頻度 )</td>
        <td >${s6_2}</td>
        </tr>
        <tr>
        <td class="t">妊娠の有無</td>
        <td >${s7_1}</td>
        </tr>
        <tr>
        <td class="t">授乳の詳細</td>
        <td >${s7_2}</td>
        </tr>
        <tr>
        <td class="t">その他・質問コメントなど</td>
        <td >${s8}</td>
        </tr>
        `;
      $(".table thead").html(thead);
      $(".table tbody").html(tbody);
    }
    // ↓データ取得の閉じかっこ
  });

  /* -----------------------
        もどるボタン
　--------------------------*/
  $(".send").on("click", function () {
    history.back();
  });

  // ↓これは消しちゃダメ！
});
