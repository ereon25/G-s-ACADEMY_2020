/*-------------------------
　 　　　　日時に関して
    -------------------------*/
// 日付の取得
var date = new Date();
//年・月・日・曜日を取得する
var year_now = date.getFullYear();
var month_now = date.getMonth() + 1;
var day_now = date.getDate();
var week_now = date.getDay();
var yobi_now = new Array("日", "月", "火", "水", "木", "金", "土");
var date_all = `
    ${year_now}-${month_now}-${day_now}(${yobi_now[week_now]})
  `;

//時刻の取得
var time = new Date();
//時・分・秒を取得する
var hour = time.getHours();
var minute = time.getMinutes();
var second = time.getSeconds();
var time_all = `
  ${hour}時${minute}分${second}秒`;
// 現在の日時まとめ
const today = {
  日付: date_all,
  時刻: time_all,
};
console.log(today);

$(document).ready(function () {
  // ↓これよりも下に記述する

  /*-------------------------
　 　　　　checkboxに関して
    -------------------------*/
  // checkboxの付け外し
  $(".only1").on("click", function () {
    $(".only1").prop("checked", false); //  全部のチェックを外す
    $(this).prop("checked", true); //  押したやつだけチェックつける
  });
  $(".only2").on("click", function () {
    $(".only2").prop("checked", false); //  全部のチェックを外す
    $(this).prop("checked", true); //  押したやつだけチェックつける
  });
  $(".only3").on("click", function () {
    $(".only3").prop("checked", false); //  全部のチェックを外す
    $(this).prop("checked", true); //  押したやつだけチェックつける
  });
  $(".only4").on("click", function () {
    $(".only4").prop("checked", false); //  全部のチェックを外す
    $(this).prop("checked", true); //  押したやつだけチェックつける
  });
  $(".only5").on("click", function () {
    $(".only5").prop("checked", false); //  全部のチェックを外す
    $(this).prop("checked", true); //  押したやつだけチェックつける
  });
  $(".only6").on("click", function () {
    $(".only6").prop("checked", false); //  全部のチェックを外す
    $(this).prop("checked", true); //  押したやつだけチェックつける
  });
  $(".only7").on("click", function () {
    $(".only7").prop("checked", false); //  全部のチェックを外す
    $(this).prop("checked", true); //  押したやつだけチェックつける
  });

  // 送信ボタンを押した後の操作
  $("#send").on("click", function () {
    /*-------------------------
　 　　　　個人情報
    -------------------------*/
    // 名前-------------------
    const name = $("#name").val();
    console.log(name);

    // 生年月日---------------
    const year = $("#year").val();
    const month = $("#month").val();
    const day = $("#day").val();
    const birthday = `
    ${year}年${month}月${day}日
    `;
    console.log(birthday);

    // 性別-------------------

    $(".sex input:checked").each(function () {
      const sex = $(this).val();
      console.log(sex);
      localStorage.setItem("性別", JSON.stringify(sex));
    });

    // 住所-------------------
    // 郵便番号
    const yuubin_num1 = $("#num1").val();
    const yuubin_num2 = $("#num2").val();
    const yuubin_num = `
    〒${yuubin_num1}-${yuubin_num2}
    `;
    console.log(yuubin_num);
    // 住所
    const yuubin_moji = $(".moji").val();
    console.log(yuubin_moji);
    // まとめ
    const address = `
    ${yuubin_num}
    ${yuubin_moji}
    `;
    console.log(address);
    // 電話番号---------------
    const tel1 = $("#tel1").val();
    const tel2 = $("#tel2").val();
    const tel3 = $("#tel3").val();
    const tel = `
    ${tel1}-${tel2}-${tel3}
    `;
    console.log(tel);
    // 個人情報まとめ
    const sex = JSON.parse(localStorage.getItem("性別"));
    console.log(sex);

    const private = {
      名前: name,
      生年月日: birthday,
      性別: sex,
      住所: address,
      電話番号: tel,
    };
    console.log(private);

    /*-------------------------
　 　　　　　　　症状
    -------------------------*/
    // １．症状内容
    const shouzyo = $("#shouzyo").val();
    console.log(shouzyo);

    // ２．病歴
    // ２－１そのほか病気の経験
    var other_sick_total = [];
    $(".q2-1 input:checked").each(function () {
      // 　クリックされたものを取得
      const other_sick = $(this).val();
      console.log(other_sick);
      other_sick_total.push(other_sick);
      console.log(other_sick_total);
      localStorage.setItem("病歴", JSON.stringify(other_sick_total));
      //   そのほかがクリックされたとき、詳細を取得
      if (other_sick == "そのほか") {
        const q2_1_other = $("#q2-1-11_detail").val();
        console.log(q2_1_other);
        localStorage.setItem("病歴_そのほか", JSON.stringify(q2_1_other));
      } else {
        const q2_1_other = "";
        localStorage.setItem("病歴_そのほか", JSON.stringify(q2_1_other));
      }
    });
    // まとめ
    const other_sick = JSON.parse(localStorage.getItem("病歴"));
    const q2_1_other = JSON.parse(localStorage.getItem("病歴_そのほか"));
    const medical_history = {
      病歴: other_sick,
      そのほか詳細: q2_1_other,
    };
    console.log(medical_history);

    // ２－２現在の病気
    $(".q2-2 input:checked").each(function () {
      const q2_2 = $(this).val();
      console.log(q2_2);
      localStorage.setItem("服用薬の有無", JSON.stringify(q2_2));
      //   「はい」がクリックされたとき、詳細を取得
      if (q2_2 == "yes") {
        const q2_2_yes = $("#q2-2_detail").val();
        console.log(q2_2_yes);
        localStorage.setItem("服用薬_詳細", JSON.stringify(q2_2_yes));
      } else {
        const q2_2_yes = "";
        localStorage.setItem("服用薬_詳細", JSON.stringify(q2_2_yes));
      }
    });
    // まとめ
    const q2_2 = JSON.parse(localStorage.getItem("服用薬の有無"));
    const q2_2_yes = JSON.parse(localStorage.getItem("服用薬_詳細"));
    const drag = {
      服用薬の有無: q2_2,
      服用薬詳細: q2_2_yes,
    };
    console.log(drag);
    // ２－３アレルギーの有無
    $(".q2-3 input:checked").each(function () {
      const q2_3 = $(this).val();
      console.log(q2_3);
      localStorage.setItem("アレルギーの有無", JSON.stringify(q2_3));
      //   「はい」がクリックされたとき、詳細を取得
      if (q2_3 == "yes") {
        const q2_3_yes = $("#q2-3_detail").val();
        console.log(q2_3_yes);
        localStorage.setItem("アレルギー_詳細", JSON.stringify(q2_3_yes));
      } else {
        const q2_3_yes = "";
        localStorage.setItem("アレルギー_詳細", JSON.stringify(q2_3_yes));
      }
    });
    // まとめ
    const q2_3 = JSON.parse(localStorage.getItem("アレルギーの有無"));
    const q2_3_yes = JSON.parse(localStorage.getItem("アレルギー_詳細"));
    const allergy = {
      アレルギーの有無: q2_3,
      アレルギー詳細: q2_3_yes,
    };
    console.log(allergy);
    // ２－４飲酒の有無
    $(".q2-4 input:checked").each(function () {
      const q2_4 = $(this).val();
      console.log(q2_4);
      localStorage.setItem("飲酒の有無", JSON.stringify(q2_4));
      //   「はい」がクリックされたとき、詳細を取得
      if (q2_4 == "yes") {
        const q2_4_yes = $("#q2-4_detail").val();
        console.log(q2_4_yes);
        localStorage.setItem("飲酒_詳細", JSON.stringify(q2_4_yes));
      } else {
        const q2_4_yes = " (-) ";
        localStorage.setItem("飲酒_詳細", JSON.stringify(q2_4_yes));
      }
    });
    // まとめ
    const q2_4 = JSON.parse(localStorage.getItem("飲酒の有無"));
    const q2_4_yes = JSON.parse(localStorage.getItem("飲酒_詳細"));
    const drinking = {
      飲酒の有無: q2_4,
      飲酒頻度: "週あたり" + q2_4_yes + "日",
    };
    console.log(drinking);
    // ２－５喫煙の有無
    $(".q2-5 input:checked").each(function () {
      const q2_5 = $(this).val();
      console.log(q2_5);
      localStorage.setItem("喫煙の有無", JSON.stringify(q2_5));
      //   「はい」がクリックされたとき、詳細を取得
      if (q2_5 == "yes") {
        const q2_5_yes = $("#q2-5_detail").val();
        console.log(q2_5_yes);
        localStorage.setItem("喫煙_詳細", JSON.stringify(q2_5_yes));
      } else {
        const q2_5_yes = " (-) ";
        localStorage.setItem("喫煙_詳細", JSON.stringify(q2_5_yes));
      }
    });
    // まとめ
    const q2_5 = JSON.parse(localStorage.getItem("喫煙の有無"));
    const q2_5_yes = JSON.parse(localStorage.getItem("喫煙_詳細"));
    const smoking = {
      喫煙の有無: q2_5,
      喫煙頻度: "１日あたり" + q2_5_yes + "本",
    };
    console.log(smoking);
    // ２－６妊娠の有無
    // 妊娠の有無
    $(".q2-6-1 input:checked").each(function () {
      const q2_6_1 = $(this).val();
      console.log(q2_6_1);
      localStorage.setItem("妊娠の有無", JSON.stringify(q2_6_1));
    });
    // 授乳の有無
    $(".q2-6-2 input:checked").each(function () {
      const q2_6_2 = $(this).val();
      console.log(q2_6_2);
      localStorage.setItem("授乳の有無", JSON.stringify(q2_6_2));
    });
    // まとめ
    const q2_6_1 = JSON.parse(localStorage.getItem("妊娠の有無"));
    const q2_6_2 = JSON.parse(localStorage.getItem("授乳の有無"));
    const pregnancy = {
      妊娠の有無: q2_6_1,
      授乳の有無: q2_6_2,
    };
    console.log(pregnancy);
    // ２－７その他質問・コメントなど
    const comment = $("#comment").val();
    console.log(comment);
    // 症状まとめ
    const symptom = {
      今回の症状: shouzyo,
      病歴について: medical_history,
      服用薬について: drag,
      アレルギーについて: allergy,
      飲酒について: drinking,
      喫煙について: smoking,
      妊娠授乳について: pregnancy,
      その他質問コメントなど: comment,
    };
    console.log(symptom);
    // すべてのまとめ
    const all = {
      時刻情報: today,
      個人情報: private,
      症状情報: symptom,
    };
    console.log(all);
    /*-------------------------
　 　Firebaseに登録する
    -------------------------*/
    const key = `
    ${year_now}${month_now}${day_now}_${tel1}${tel2}${tel3}
    `;
    // var json_text = JSON.stringify(all);
    newPostRef.push({
      患者情報: all,
      // 患者情報: json_text,
    });

    /*-------------------------
　 　localStrage内を空にする
    -------------------------*/
    localStorage.clear();

    /*-------------------------
　 　完了画面の表示をする
    -------------------------*/
    $(".finish").html(
      '<p class="finish"><img src="../img/finish.png" width=350px height=100%></p>'
    );
    // ↓これはクリックイベントの閉じかっこ！
  });
  // ↓これは消しちゃダメ！
});
