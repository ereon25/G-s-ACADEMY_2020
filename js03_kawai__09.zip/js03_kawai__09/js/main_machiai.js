$(document).ready(function () {
  // ↓これよりも下に記述する

  newPostRef.on("child_added", function (data) {
    /* -----------------------
        データを取得 
    --------------------------*/
    var all_data = data.val();
    console.log(all_data);
    var all_data_key = data.key;
    console.log(all_data_key);
    var all_data_key_json = localStorage.setItem(
      "id",
      JSON.stringify(all_data_key)
    );

    /* -----------------------
        詳細項目データを取得 
    --------------------------*/
    // 日付
    var th2 = `${all_data.患者情報.時刻情報.日付}`;
    // 時刻
    var th3 = `${all_data.患者情報.時刻情報.時刻}`;
    // 名前
    var th4 = `${all_data.患者情報.個人情報.名前}`;
    // 生年月日
    var th5 = `${all_data.患者情報.個人情報.生年月日}`;
    // 性別
    var th6 = `${all_data.患者情報.個人情報.性別}`;

    console.log(all_data_key);

    /* -----------------------
        表の追加
    --------------------------*/

    $("tbody").append(
      `<tr>
          <td class="td1"><input type="checkbox" id="${all_data_key}" value="${all_data_key}"></td>
          <td class="td2">${th2}</td>
          <td class="td3">${th3}</td>
          <td class="td4">${th4}</td>
          <td class="td5">${th5}</td>
          <td class="td6">${th6}</td>
        </tr>`
    );

    /*-------------------------
　 　　　　checkboxに関して
    -------------------------*/
    // checkboxの付け外し
    $(".only").on("click", function () {
      $(".only").prop("checked", false); //  全部のチェックを外す
      $(this).prop("checked", true); //  押したやつだけチェックつける
    });

    // ↓データ取得繰り返しの閉じかっこ！
  });

  // 詳細表示ボタンを押した後の操作
  $(".detail").on("click", function () {
    /* -----------------------
        詳細表示について
    --------------------------*/
    var check_all = [];
    $(".td1 input:checked").each(function () {
      // 　クリックされたものを取得
      const check = $(this).val();
      console.log(check);
      check_all.push(check);
      console.log(check_all);
      localStorage.setItem("id", JSON.stringify(check_all));
      location.href =
        "file:///C:/Users/b1316/OneDrive/%E3%83%89%E3%82%AD%E3%83%A5%E3%83%A1%E3%83%B3%E3%83%88/programing/%E7%AC%AC%E5%9B%9B%E5%9B%9E_200426/camp_firebase/camp_firebase/kadai/html/machiai2.html? id=" +
        encodeURIComponent(check_all);
    });
    // ↓これはクリックイベントの閉じかっこ！
  });
  // ↓これは消しちゃダメ！
});
