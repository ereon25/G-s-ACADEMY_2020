$(document).ready(function () {
  // 最終的になりたいvalueの形態
  var value = { face: "face__id", fuku: "fuku__id" };

  /*ーーーーーーーーー
  　　　1．名前 
  ーーーーーーーーーー*/

  /*ーーーーーーーーー
  　　　2．顔 
  ーーーーーーーーーー*/
  //   2－1．クマを選択ーーーーーー
  $(".face1").on("click", function () {
    // クリック画像のid取得
    var face__id = $(this).attr("id");
    console.log(JSON.stringify(face__id));
    // クマ画像表示（服なし）
    $(".visual p").html('<img src="../img/body1.png">');
    // データを保存する
    const value1 = localStorage.setItem("face", face__id);
  });

  //   2－2．うさぎを選択ーーーーーーー
  $(".face2").on("click", function () {
    // クリック画像のid取得
    var face__id = $(this).attr("id");
    console.log(JSON.stringify(face__id));
    // うさぎ画像表示（服なし）
    $(".visual p").html('<img src="../img/body2.png">');
    // データを保存する
    const value1 = localStorage.setItem("face", face__id);
  });

  /*ーーーーーーーーー
  　　　　3．服 
  ーーーーーーーーーー*/
  // 3-1.チェックの服を選んだ時ーーーーーーーーー
  $(".fuku1").on("click", function () {
    const value1_back = localStorage.getItem("face");
    console.log(value1_back);

    if (value1_back == "face1") {
      // クリック画像のid取得
      var fuku__id = $(this).attr("id");
      console.log(JSON.stringify(fuku__id));
      // くま画像表示（服１）
      $(".visual p").html('<img src="../img/1-1.png">');
      // データを保存する
      const value2 = localStorage.setItem("fuku", fuku__id);
    }
    if (value1_back == "face2") {
      // クリック画像のid取得
      fuku__id = $(this).attr("id");
      console.log(JSON.stringify(fuku__id));
      // うさぎ画像表示（服１）
      $(".visual p").html('<img src="../img/2-1.png">');
      // データを保存する
      const value2 = localStorage.setItem("fuku", fuku__id);
    }
    // ↓clickの閉じかっこ
  });

  // 3-2.涙の服を選んだ時ーーーーーーーーー
  $(".fuku2").on("click", function () {
    const value1_back = localStorage.getItem("face");
    console.log(value1_back);

    if (value1_back == "face1") {
      // クリック画像のid取得
      var fuku__id = $(this).attr("id");
      console.log(JSON.stringify(fuku__id));
      // くま画像表示（服２）
      $(".visual p").html('<img src="../img/1-2.png">');
      // データを保存する
      const value2 = localStorage.setItem("fuku", fuku__id);
    }
    if (value1_back == "face2") {
      // クリック画像のid取得
      fuku__id = $(this).attr("id");
      console.log(JSON.stringify(fuku__id));
      // うさぎ画像表示（服２）
      $(".visual p").html('<img src="../img/2-2.png">');
      // データを保存する
      const value2 = localStorage.setItem("fuku", fuku__id);
    }
    // ↓clickの閉じかっこ
  });

  // 3-3.レモンの服を選んだ時ーーーーーーーーー
  $(".fuku3").on("click", function () {
    const value1_back = localStorage.getItem("face");
    console.log(value1_back);

    if (value1_back == "face1") {
      // クリック画像のid取得
      var fuku__id = $(this).attr("id");
      console.log(JSON.stringify(fuku__id));
      // くま画像表示（服３）
      $(".visual p").html('<img src="../img/1-3.png">');
      // データを保存する
      const value2 = localStorage.setItem("fuku", fuku__id);
    }
    if (value1_back == "face2") {
      // クリック画像のid取得
      fuku__id = $(this).attr("id");
      console.log(JSON.stringify(fuku__id));
      // うさぎ画像表示（服３）
      $(".visual p").html('<img src="../img/2-3.png">');
      // データを保存する
      const value2 = localStorage.setItem("fuku", fuku__id);
    }
    // ↓clickの閉じかっこ
  });

  /*ーーーーーーーーー
    　　　保存ボタン 
    ーーーーーーーーーー*/
  //Save クリックイベント
  $("#save").on("click", function () {
    // val()で値を取得する
    const key = $("#name").val();
    // html側で入力されたデータを取得して確認
    console.log(key);
    // value1/value2を取得
    const value1_back = localStorage.getItem("face");
    console.log(value1_back);
    const value2_back = localStorage.getItem("fuku");
    console.log(value2_back);
    // value1/value2を取得
    const value = {
      face: value1_back,
      fuku: value2_back,
    };
    console.log(value);
    $(".finish").fadeIn(400);

    // データを保存する
    localStorage.setItem(key, JSON.stringify(value));
    //------------------------------------
    // valueの中からvalue1/value2をそれぞれ取得
    var value1_finish = value.face;
    var value2_finish = value.fuku;
    console.log(value1_finish);
    console.log(value2_finish);
    // Welcom画像表示
    $(".finish,.old,.old_bye").fadeIn(800);
    // 名前表示
    $(".finish__name p").html(key);
    // value1/value2の値によって画像表示
    function call() {
      // 1.くまを選択した人--------------------
      // 1-1.チェックの服を選択した人
      if (value1_finish == "face1" && value2_finish == "fuku1") {
        $(".finish__visual p").html(
          '<img src="../img/1-1.png" width=250px height=100%>'
        );
      }
      // 1-2.涙の服を選択した人
      if (value1_finish == "face1" && value2_finish == "fuku2") {
        $(".finish__visual p").html(
          '<img src="../img/1-2.png" width=250px height=100%>'
        );
      }
      // 1-3.レモンの服を選択した人
      if (value1_finish == "face1" && value2_finish == "fuku3") {
        $(".finish__visual p").html(
          '<img src="../img/1-3.png" width=250px height=100%>'
        );
      }
      // 2.ウサギを選択した人--------------------
      // 2-1.チェックの服を選択した人
      if (value1_finish == "face2" && value2_finish == "fuku1") {
        $(".finish__visual p").html(
          '<img src="../img/2-1.png" width=250px height=100%>'
        );
      }
      // 2-2.涙の服を選択した人
      if (value1_finish == "face2" && value2_finish == "fuku2") {
        $(".finish__visual p").html(
          '<img src="../img/2-2.png" width=250px height=100%>'
        );
      }
      // 2-3.レモンの服を選択した人
      if (value1_finish == "face2" && value2_finish == "fuku3") {
        $(".finish__visual p").html(
          '<img src="../img/2-3.png" width=250px height=100%>'
        );
      }
    }
    call();
    // ↓保存ボタンの閉じかっこ
  });

  /*ーーーーーーーーー
  　　　クリアボタン 
  ーーーーーーーーーー*/
  // $("#clear").on("click", function () {
  //   localStorage.clear();
  // });

  // \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
  /*ーーーーーーーーー
  　　過去のキャラを呼ぶ
  ーーーーーーーーーー*/
  $("#call").on("click", function () {
    // val()で値を取得する
    const call_name = $("#old_name").val();
    console.log(old_name);
    // 入力名をもとにvalue1/value2を呼び出し取得
    var callback = JSON.parse(localStorage.getItem(call_name));
    console.log(callback);
    var value1_callback = callback.face;
    var value2_callback = callback.fuku;
    console.log(value1_callback);
    console.log(value2_callback);
    // Welcom画像表示
    $(".finish,.old,.old_bye").fadeIn(800);
    // 名前表示
    $(".finish__name p").html(call_name);
    // value1/value2の値によって画像表示
    function call() {
      // 1.くまを選択した人--------------------
      // 1-1.チェックの服を選択した人
      if (value1_callback == "face1" && value2_callback == "fuku1") {
        $(".finish__visual p").html(
          '<img src="../img/1-1.png" width=250px height=100%>'
        );
      }
      // 1-2.涙の服を選択した人
      if (value1_callback == "face1" && value2_callback == "fuku2") {
        $(".finish__visual p").html(
          '<img src="../img/1-2.png" width=250px height=100%>'
        );
      }
      // 1-3.レモンの服を選択した人
      if (value1_callback == "face1" && value2_callback == "fuku3") {
        $(".finish__visual p").html(
          '<img src="../img/1-3.png" width=250px height=100%>'
        );
      }
      // 2.ウサギを選択した人--------------------
      // 2-1.チェックの服を選択した人
      if (value1_callback == "face2" && value2_callback == "fuku1") {
        $(".finish__visual p").html(
          '<img src="../img/2-1.png" width=250px height=100%>'
        );
      }
      // 2-2.涙の服を選択した人
      if (value1_callback == "face2" && value2_callback == "fuku2") {
        $(".finish__visual p").html(
          '<img src="../img/2-2.png" width=250px height=100%>'
        );
      }
      // 2-3.レモンの服を選択した人
      if (value1_callback == "face2" && value2_callback == "fuku3") {
        $(".finish__visual p").html(
          '<img src="../img/2-3.png" width=250px height=100%>'
        );
      }
    }
    call();
  });

  /*ーーーーーーーーー
  　　　お別れボタン 
  ーーーーーーーーーー*/
  // この子(過去の名前)とお別れする
  $("#bye").on("click", function () {
    const call_name = $("#old_name").val();
    localStorage.removeItem(call_name);
    alert("bye!");
  });
  // 全員とお別れする
  $("#bye_all").on("click", function () {
    localStorage.clear();
    alert("See you!");
  });

  // ↓消しちゃダメ！
});
