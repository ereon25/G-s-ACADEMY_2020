-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- ホスト: localhost:3307
-- 生成日時: 
-- サーバのバージョン： 5.7.24
-- PHP のバージョン: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `gs_db`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `ec_table`
--

CREATE TABLE `ec_table` (
  `id` int(12) NOT NULL,
  `item` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `value` int(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `fname` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `indate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `ec_table`
--

INSERT INTO `ec_table` (`id`, `item`, `value`, `description`, `fname`, `indate`) VALUES
(1, 'レスポンシブWebデザイン', 2000, 'レスポンシブ最高の本。', 'responsiv.jpg', '2020-05-31 10:44:35'),
(2, 'MVP', 1000, 'MVP最高！', '2016-07-21 08.12.00.png', '2020-05-31 10:47:00'),
(3, 'BingMVP', 0, 'ありがとうございます。', 'logo2.png', '2020-05-31 10:47:31'),
(4, 'THE　CELL', 2147483647, 'テスト', 'responsiv.jpg', '2020-05-31 10:47:54');

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_an_table`
--

CREATE TABLE `gs_an_table` (
  `id` int(12) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `naiyou` text COLLATE utf8_unicode_ci,
  `indate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `gs_an_table`
--

INSERT INTO `gs_an_table` (`id`, `name`, `email`, `naiyou`, `indate`) VALUES
(1, 'ジーズ太郎', 'test1@test.test', 'テスト１', '2015-06-15 00:00:00'),
(2, 'ジーズ次郎', 'test2@test.test', 'テスト２', '2020-05-23 09:35:23');

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_bm_table`
--

CREATE TABLE `gs_bm_table` (
  `id` int(12) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci,
  `naiyou` text COLLATE utf8_unicode_ci,
  `indate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `gs_bm_table`
--

INSERT INTO `gs_bm_table` (`id`, `name`, `email`, `naiyou`, `indate`) VALUES
(1, 'PHP本', 'http://php.jp', '読みたい本', '2020-05-23 09:41:20'),
(2, 'PHP&JS', 'http://JS.jp', '困ったら再度読みたい', '2020-05-23 09:41:20'),
(3, 'PY', 'http://php1.jp', '読みたい本１', '2020-05-23 09:43:26'),
(4, 'PHP2本', 'http://php2.jp', '読みたい本２', '2020-05-23 09:45:51'),
(5, 'PHP3本', 'http://php3.jp', '読みたい本３', '2020-05-23 09:45:51'),
(6, 'PHP4本', 'http://php4.jp', '読みたい本４', '2020-05-23 10:46:25'),
(7, 'RB', 'http://php5.jp', '読みたい本５', '2020-05-23 10:46:25'),
(8, 'PHP6本', 'http://php6.jp', '読みたい本６', '2020-05-23 10:46:25'),
(9, 'PY', 'http://php7.jp', '読みたい本７', '2020-05-23 09:45:51'),
(10, 'PHP8本', 'http://php8.jp', '読みたい本８', '2020-05-23 09:45:51'),
(11, 'PHP9本', 'http://php9.jp', '読みたい本９', '2020-05-23 09:45:51'),
(12, 'PHP10本', 'http://php10.jp', '読みたい本１０', '2020-05-23 09:45:51'),
(13, 'PHP本X', 'http://php11.php', '未入力', '2018-05-19 00:00:00');

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_presen_login_table`
--

CREATE TABLE `gs_presen_login_table` (
  `id` int(11) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `birth` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `life_flag` int(1) NOT NULL DEFAULT '1',
  `indate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `gs_presen_login_table`
--

INSERT INTO `gs_presen_login_table` (`id`, `name`, `birth`, `user_id`, `pass`, `life_flag`, `indate`) VALUES
(1, 'もりの　くまこ', '2020-05-07', 'test', 'test_pass', 1, '2020-06-01 00:27:33'),
(2, 'のはら　うさこ', '2020-05-26', 'test1', 'test_pass1', 1, '2020-05-31 18:19:50');

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_user_table`
--

CREATE TABLE `gs_user_table` (
  `id` int(12) NOT NULL,
  `user_name` varchar(24) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `flg` int(1) NOT NULL,
  `indate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `gs_user_table`
--

INSERT INTO `gs_user_table` (`id`, `user_name`, `user_id`, `pass`, `flg`, `indate`) VALUES
(1, 'A0001', 'テスト１', 'test1', 0, '2020-05-23 11:48:22'),
(2, 'A0002', 'テスト２', 'test2', 0, '2020-05-23 11:53:17'),
(3, 'A0003', 'テスト３', 'test3', 0, '2020-05-23 11:53:17'),
(4, 'B0004', 'テスト４', 'test4', 0, '2020-05-23 11:53:17'),
(5, 'B0005', 'テスト５', 'test5', 0, '2020-05-23 11:53:17'),
(6, 'B0006', 'テスト６', 'test6', 0, '2020-05-23 11:53:17'),
(7, 'C0007', 'テスト７', 'test7', 0, '2020-05-23 11:53:17'),
(8, 'C0008', 'テスト８', 'test8', 0, '2020-05-23 11:53:17'),
(9, 'C0009', 'テスト９', 'test9', 0, '2020-05-23 11:53:17'),
(10, 'C0010', 'テスト１０', 'test10', 0, '2020-05-23 11:53:17'),
(11, 'A0004', 'テスト１１', 'test11', 1, '2020-05-23 11:53:17');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `ec_table`
--
ALTER TABLE `ec_table`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `gs_an_table`
--
ALTER TABLE `gs_an_table`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `gs_bm_table`
--
ALTER TABLE `gs_bm_table`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `gs_presen_login_table`
--
ALTER TABLE `gs_presen_login_table`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `gs_user_table`
--
ALTER TABLE `gs_user_table`
  ADD PRIMARY KEY (`id`);

--
-- ダンプしたテーブルのAUTO_INCREMENT
--

--
-- テーブルのAUTO_INCREMENT `ec_table`
--
ALTER TABLE `ec_table`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- テーブルのAUTO_INCREMENT `gs_an_table`
--
ALTER TABLE `gs_an_table`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- テーブルのAUTO_INCREMENT `gs_bm_table`
--
ALTER TABLE `gs_bm_table`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- テーブルのAUTO_INCREMENT `gs_presen_login_table`
--
ALTER TABLE `gs_presen_login_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- テーブルのAUTO_INCREMENT `gs_user_table`
--
ALTER TABLE `gs_user_table`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
